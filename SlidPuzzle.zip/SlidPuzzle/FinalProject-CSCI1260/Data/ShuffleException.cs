﻿namespace FinalProject_CSCI1260.Data
{
    public class ShuffleException : Exception
    {
        public ShuffleException(string message) : base(message) { }
    }
}
