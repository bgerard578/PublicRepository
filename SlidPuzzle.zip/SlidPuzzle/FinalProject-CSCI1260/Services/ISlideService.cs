﻿using FinalProject_CSCI1260.Data;

namespace FinalProject_CSCI1260.Services
{
    public interface ISlideService
    {
        public Tiles alltiles { get; set; }
    }
}
